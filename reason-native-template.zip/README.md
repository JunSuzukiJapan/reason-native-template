# Basic Reason Template

Hello! This project allows you to quickly get started with Reason and BuckleScript. If you wanted a more sophisticated version, try the `react` template (`bsb -theme react -init .`).

# Build
```
npm run build
```

# Build + Run

```
npm run run
```

# Test

```
npm test
```

# Editor
If you use `vscode`, Press `Cmd + Shift + B` it will build automatically, and Press `Cmd + Shift + T` it will run UnitTest automativally.
